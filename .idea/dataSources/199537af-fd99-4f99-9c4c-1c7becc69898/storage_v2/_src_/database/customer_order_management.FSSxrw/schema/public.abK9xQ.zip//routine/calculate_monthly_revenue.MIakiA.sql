create procedure calculate_monthly_revenue()
    language plpgsql
as
$$
declare 
total_get decimal;
month_calculate month_enum;
begin
	select sum(total_bill) into total_get from completed_order co WHERE EXTRACT(MONTH FROM order_date) = extract (month from current_date);
	select to_char(to_date((extract (month from current_date))::text, 'MM'), 'Month') into month_calculate;
	insert into monthly_revenue (month_released, total_revenue) values (month_calculate, total_get);
commit;
end
$$;

alter procedure calculate_monthly_revenue() owner to phamtrang;

