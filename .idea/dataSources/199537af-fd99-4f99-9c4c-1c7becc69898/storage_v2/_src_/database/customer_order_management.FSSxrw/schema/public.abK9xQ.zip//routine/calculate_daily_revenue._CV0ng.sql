create procedure calculate_daily_revenue()
    language plpgsql
as
$$
declare 
total_get decimal;
begin 
select sum(total_bill) into total_get from completed_order co where date(order_date) = current_date ;
insert into daily_revenue (date_released, total_revenue) values ( current_date, total_get);
commit;

end
$$;

alter procedure calculate_daily_revenue() owner to phamtrang;

